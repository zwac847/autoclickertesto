package com.mobilclicker.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.view.KeyEvent;

/** Tüm ayarlar burada saklanır. Servis ve ekran aynı dosyayı okur. */
public final class Prefs {
    public static final int MODE_MOUSE = 0; // fare imlecinin olduğu yere tıkla
    public static final int MODE_FIXED = 1; // seçilen sabit noktaya tıkla

    private final SharedPreferences sp;

    public Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("clicker", Context.MODE_PRIVATE);
    }

    /** İki tık arası süre (ms). */
    public int interval() { return sp.getInt("interval", 100); }
    public void setInterval(int v) { sp.edit().putInt("interval", v).apply(); }

    /** Rastgele sapma (ms): aralığa +/- bu kadar eklenir. */
    public int jitter() { return sp.getInt("jitter", 0); }
    public void setJitter(int v) { sp.edit().putInt("jitter", v).apply(); }

    /** Dokunuşun basılı kalma süresi (ms). */
    public int hold() { return sp.getInt("hold", 10); }
    public void setHold(int v) { sp.edit().putInt("hold", v).apply(); }

    /** Toplam tık sayısı (0 = sınırsız). */
    public int max() { return sp.getInt("max", 0); }
    public void setMax(int v) { sp.edit().putInt("max", v).apply(); }

    /** Başlamadan önce bekleme (ms). */
    public int delay() { return sp.getInt("delay", 0); }
    public void setDelay(int v) { sp.edit().putInt("delay", v).apply(); }

    public int mode() {
        return sp.getInt("mode", Build.VERSION.SDK_INT >= 34 ? MODE_MOUSE : MODE_FIXED);
    }
    public void setMode(int v) { sp.edit().putInt("mode", v).apply(); }

    public float fixedX() { return sp.getFloat("fx", -1f); }
    public float fixedY() { return sp.getFloat("fy", -1f); }
    public void setFixed(float x, float y) {
        sp.edit().putFloat("fx", x).putFloat("fy", y).apply();
    }

    public int hotkey() { return sp.getInt("hotkey", KeyEvent.KEYCODE_F6); }
    public void setHotkey(int v) { sp.edit().putInt("hotkey", v).apply(); }

    /** Çalışırken ekranda küçük "AKTİF" rozeti göster. */
    public boolean badge() { return sp.getBoolean("badge", true); }
    public void setBadge(boolean v) { sp.edit().putBoolean("badge", v).apply(); }
}
