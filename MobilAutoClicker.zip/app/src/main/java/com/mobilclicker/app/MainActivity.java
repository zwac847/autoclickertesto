package com.mobilclicker.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Ayar ekranı: hız, nokta, kısayol ve gelişmiş seçenekler. */
public class MainActivity extends Activity {

    private static final int BLUE = 0xFF3D7BFF;
    private static final int GRAY = 0xFF2C3444;
    private static final int GREEN = 0xFF1FA463;

    private Prefs p;
    private TextView statusTv;
    private TextView coordTv;
    private TextView cpsTv;
    private EditText etInterval;
    private EditText etJitter;
    private EditText etHold;
    private EditText etMax;
    private EditText etDelay;
    private RadioButton rbMouse;
    private RadioButton rbFixed;
    private Spinner spHotkey;
    private CheckBox cbBadge;
    private boolean ready;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = new Prefs(this);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF0F131A);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(28), dp(16), dp(28));
        sv.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("Mobil Auto Clicker", 26, Color.WHITE, true);
        root.addView(title);
        TextView sub = text("Klavye ve fare takılı telefonlar için", 14, 0xFF9AA4B5, false);
        sub.setPadding(0, dp(2), 0, dp(16));
        root.addView(sub);

        // ---- Durum
        LinearLayout c1 = card();
        statusTv = text("", 16, Color.WHITE, true);
        c1.addView(statusTv);
        Button openSettings = btn("Erişilebilirlik ayarlarını aç", BLUE, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                Toast.makeText(MainActivity.this,
                        "Mobil Auto Clicker'ı bulup aç", Toast.LENGTH_LONG).show();
            }
        });
        c1.addView(openSettings, matchWrap(dp(10)));
        root.addView(c1);

        // ---- Hız
        LinearLayout c2 = card();
        c2.addView(text("Hız", 18, Color.WHITE, true));
        c2.addView(label("İki tık arası süre (ms)"));
        etInterval = number(p.interval());
        c2.addView(etInterval);
        cpsTv = text("", 13, 0xFF7FB2FF, false);
        c2.addView(cpsTv);

        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        int[] pv = {10, 50, 100, 250, 500, 1000};
        for (final int v : pv) {
            Button pb = btn(v >= 1000 ? "1sn" : String.valueOf(v), GRAY, new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    etInterval.setText(String.valueOf(v));
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(dp(2), dp(8), dp(2), 0);
            presets.addView(pb, lp);
        }
        c2.addView(presets);

        c2.addView(label("Rastgele sapma ± (ms) — insan gibi görünmesi için"));
        etJitter = number(p.jitter());
        c2.addView(etJitter);
        root.addView(c2);

        // ---- Nokta
        LinearLayout c3 = card();
        c3.addView(text("Tıklama noktası", 18, Color.WHITE, true));
        RadioGroup rg = new RadioGroup(this);
        rbMouse = new RadioButton(this);
        rbMouse.setText("Fare imlecinin olduğu yer (Android 14+)");
        rbMouse.setTextColor(Color.WHITE);
        rbMouse.setId(View.generateViewId());
        rbFixed = new RadioButton(this);
        rbFixed.setText("Sabit nokta");
        rbFixed.setTextColor(Color.WHITE);
        rbFixed.setId(View.generateViewId());
        rg.addView(rbMouse);
        rg.addView(rbFixed);
        c3.addView(rg);
        if (Build.VERSION.SDK_INT < 34) {
            rbMouse.setEnabled(false);
            rbMouse.setText("Fare imleci (bu telefonda yok, Android 14+ gerekir)");
            rbFixed.setChecked(true);
        } else if (p.mode() == Prefs.MODE_FIXED) {
            rbFixed.setChecked(true);
        } else {
            rbMouse.setChecked(true);
        }
        coordTv = text("", 14, 0xFF9AA4B5, false);
        c3.addView(coordTv);
        c3.addView(btn("Sabit nokta seç", GRAY, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClickService s = ClickService.instance;
                if (s == null) {
                    Toast.makeText(MainActivity.this,
                            "Önce erişilebilirlik servisini aç", Toast.LENGTH_LONG).show();
                    return;
                }
                s.beginPick(new Runnable() {
                    @Override
                    public void run() {
                        refresh();
                    }
                });
                moveTaskToBack(true);
            }
        }), matchWrap(dp(8)));
        root.addView(c3);

        // ---- Gelişmiş
        LinearLayout c4 = card();
        c4.addView(text("Gelişmiş", 18, Color.WHITE, true));
        c4.addView(label("Dokunuşun basılı kalma süresi (ms)"));
        etHold = number(p.hold());
        c4.addView(etHold);
        c4.addView(label("Toplam tık sayısı (0 = sınırsız)"));
        etMax = number(p.max());
        c4.addView(etMax);
        c4.addView(label("Başlamadan önce bekleme (ms)"));
        etDelay = number(p.delay());
        c4.addView(etDelay);
        c4.addView(label("Açma/kapama kısayolu"));
        spHotkey = new Spinner(this);
        String[] keys = new String[12];
        for (int i = 0; i < 12; i++) keys[i] = "F" + (i + 1);
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, keys);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spHotkey.setAdapter(ad);
        int sel = p.hotkey() - KeyEvent.KEYCODE_F1;
        spHotkey.setSelection(sel >= 0 && sel < 12 ? sel : 5);
        c4.addView(spHotkey);
        cbBadge = new CheckBox(this);
        cbBadge.setText("Çalışırken ekranda \"AKTİF\" rozeti göster");
        cbBadge.setTextColor(Color.WHITE);
        cbBadge.setChecked(p.badge());
        c4.addView(cbBadge);
        root.addView(c4);

        // ---- Test + bilgi
        LinearLayout c5 = card();
        c5.addView(btn("▶ / ■  3 sn sonra başlat (test)", GREEN, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClickService s = ClickService.instance;
                if (s == null) {
                    Toast.makeText(MainActivity.this,
                            "Önce erişilebilirlik servisini aç", Toast.LENGTH_LONG).show();
                    return;
                }
                save();
                if (s.isRunning()) {
                    s.stopClicking(true);
                } else {
                    s.startClicking(3000);
                    moveTaskToBack(true);
                }
            }
        }), matchWrap(0));
        TextView info = text(
                "• Kısayol her uygulamanın üstünde çalışır, uygulama arka planda olabilir.\n"
                        + "• Fare modunda tık, fare imlecinin son görüldüğü yere gider. "
                        + "Başlatmadan önce fareyi hedefe götür.\n"
                        + "• Sol tık (tek dokunuş) taklit edilir. Sağ tık ve çift tık yok.\n"
                        + "• Çok düşük aralıklarda telefon hızı kendisi sınırlayabilir.",
                13, 0xFF9AA4B5, false);
        info.setPadding(0, dp(12), 0, 0);
        c5.addView(info);
        root.addView(c5);

        setContentView(sv);

        // Dinleyiciler en sonda: yarım kurulu ekranda kayıt tetiklenmesin
        TextWatcher watcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b2, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b2, int c) {
            }

            @Override
            public void afterTextChanged(Editable e) {
                save();
            }
        };
        etInterval.addTextChangedListener(watcher);
        etJitter.addTextChangedListener(watcher);
        etHold.addTextChangedListener(watcher);
        etMax.addTextChangedListener(watcher);
        etDelay.addTextChangedListener(watcher);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                save();
            }
        });
        cbBadge.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton v, boolean checked) {
                save();
            }
        });
        spHotkey.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                if (!ready) return;
                p.setHotkey(KeyEvent.KEYCODE_F1 + pos);
                refresh();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        ready = true;
        updateCps();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        save();
    }

    // ---------------------------------------------------------------- mantık

    private void save() {
        if (!ready) return;
        p.setInterval(num(etInterval, 100, 1));
        p.setJitter(num(etJitter, 0, 0));
        p.setHold(num(etHold, 10, 1));
        p.setMax(num(etMax, 0, 0));
        p.setDelay(num(etDelay, 0, 0));
        p.setMode(rbFixed.isChecked() ? Prefs.MODE_FIXED : Prefs.MODE_MOUSE);
        p.setBadge(cbBadge.isChecked());
        updateCps();
    }

    private void updateCps() {
        int iv = num(etInterval, 100, 1);
        cpsTv.setText(String.format(Locale.US, "≈ %.1f tık/sn", 1000.0 / iv));
    }

    private void refresh() {
        String key = "F" + (p.hotkey() - KeyEvent.KEYCODE_F1 + 1);
        if (ClickService.instance != null) {
            statusTv.setText("✅ Servis açık — " + key + " ile başlat/durdur");
            statusTv.setTextColor(0xFF5BE39B);
        } else {
            statusTv.setText("⚠️ Servis kapalı — aşağıdan erişilebilirlikte aç");
            statusTv.setTextColor(0xFFFFC857);
        }
        if (p.fixedX() >= 0) {
            coordTv.setText("Kayıtlı nokta: " + (int) p.fixedX() + ", " + (int) p.fixedY());
        } else {
            coordTv.setText("Sabit nokta henüz seçilmedi");
        }
    }

    private int num(EditText e, int def, int min) {
        try {
            long v = Long.parseLong(e.getText().toString().trim());
            if (v < min) v = min;
            if (v > 2000000000L) v = 2000000000L;
            return (int) v;
        } catch (Exception ex) {
            return def;
        }
    }

    // ---------------------------------------------------------------- küçük yardımcılar

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String t, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    private TextView label(String t) {
        TextView tv = text(t, 13, 0xFF9AA4B5, false);
        tv.setPadding(0, dp(12), 0, 0);
        return tv;
    }

    private EditText number(int value) {
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setSingleLine(true);
        e.setTextColor(Color.WHITE);
        e.setText(String.valueOf(value));
        return e;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF1B212C);
        g.setCornerRadius(dp(14));
        l.setBackground(g);
        l.setPadding(dp(16), dp(14), dp(16), dp(16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        l.setLayoutParams(lp);
        return l;
    }

    private LinearLayout.LayoutParams matchWrap(int topMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, topMargin, 0, 0);
        return lp;
    }

    private Button btn(String t, int color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(10));
        b.setBackground(g);
        b.setOnClickListener(l);
        return b;
    }
}
